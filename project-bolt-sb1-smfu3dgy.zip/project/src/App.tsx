import { useState, useMemo, useCallback } from 'react';
import { TopNav } from '@/components/TopNav';
import { LeftPanel } from '@/components/LeftPanel';
import { ThreatGraph } from '@/components/ThreatGraph';
import { Timeline } from '@/components/Timeline';
import { RightPanel } from '@/components/RightPanel';
import { NODES, EDGES, DEFAULT_WEIGHTS } from '@/data';
import type { SignalWeights } from '@/types';

export default function App() {
  const [search, setSearch] = useState('');
  const [threshold, setThreshold] = useState(0.7);
  const [weights, setWeights] = useState<SignalWeights>(DEFAULT_WEIGHTS);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>('n1');
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const selectedNode = useMemo(
    () => NODES.find((n) => n.id === selectedNodeId) ?? null,
    [selectedNodeId],
  );
  const selectedEdge = useMemo(
    () => EDGES.find((e) => e.id === selectedEdgeId) ?? null,
    [selectedEdgeId],
  );

  const visibleCount = useMemo(() => EDGES.filter((e) => e.score >= threshold).length, [threshold]);

  const handleToggle = useCallback((key: keyof SignalWeights) => {
    setWeights((prev) => {
      const off = prev[key] === 0;
      const defaults = DEFAULT_WEIGHTS[key];
      return { ...prev, [key]: off ? defaults : 0 };
    });
  }, []);

  const handleSelectNode = useCallback((id: string | null) => {
    setSelectedNodeId(id);
    setSelectedEdgeId(null);
  }, []);

  const handleSelectEdge = useCallback((id: string | null) => {
    setSelectedEdgeId(id);
    if (id) {
      const edge = EDGES.find((e) => e.id === id);
      if (edge) setSelectedNodeId(edge.source);
    }
  }, []);

  const handleRunPipeline = useCallback(() => {
    setRunning(true);
    window.setTimeout(() => setRunning(false), 1400);
  }, []);

  const handleExport = useCallback(() => {
    window.alert('Evidence PDF export queued for case I4C-2025-0841.');
  }, []);

  // highlight connected nodes when an edge is selected
  const highlightNodeIds = useMemo(() => {
    if (selectedEdgeId) {
      const e = EDGES.find((x) => x.id === selectedEdgeId);
      if (e) return new Set([e.source, e.target]);
    }
    if (selectedNodeId) return new Set([selectedNodeId]);
    return new Set<string>();
  }, [selectedEdgeId, selectedNodeId]);

  // search filter: if search matches a node, select it
  const handleSearch = useCallback((v: string) => {
    setSearch(v);
    const q = v.trim().toLowerCase();
    if (!q) return;
    const match = NODES.find(
      (n) =>
        n.handle.toLowerCase().includes(q) ||
        n.label.toLowerCase().includes(q),
    );
    if (match) {
      setSelectedNodeId(match.id);
      setSelectedEdgeId(null);
    }
  }, []);

  return (
    <div className="flex h-screen flex-col bg-[#090d16] text-slate-200">
      <TopNav search={search} onSearch={handleSearch} />
      <div className="grid flex-1 grid-cols-[25%_50%_25%] overflow-hidden">
        <LeftPanel
          threshold={threshold}
          onThreshold={setThreshold}
          weights={weights}
          onToggle={handleToggle}
          onRunPipeline={handleRunPipeline}
          onExport={handleExport}
          running={running}
          edgeCount={EDGES.length}
          visibleCount={visibleCount}
        />

        <main className="flex flex-col overflow-hidden">
          <div className="flex-1 overflow-hidden">
            <ThreatGraph
              nodes={NODES}
              edges={EDGES}
              threshold={threshold}
              selectedNodeId={selectedNodeId}
              selectedEdgeId={selectedEdgeId}
              onSelectNode={handleSelectNode}
              onSelectEdge={handleSelectEdge}
              highlightNodeIds={highlightNodeIds}
            />
          </div>
          <div className="h-[30%] shrink-0">
            <Timeline
              edges={EDGES}
              nodes={NODES}
              threshold={threshold}
              onSelectNode={handleSelectNode}
              selectedNodeId={selectedNodeId}
            />
          </div>
        </main>

        <RightPanel
          node={selectedNode}
          edges={EDGES}
          selectedEdge={selectedEdge}
          weights={weights}
          threshold={threshold}
        />
      </div>
    </div>
  );
}
