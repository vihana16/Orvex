import { Play, FileText, Sliders, KeyRound, Wallet, PenTool, Fingerprint } from 'lucide-react';
import type { SignalWeights } from '@/types';

interface LeftPanelProps {
  threshold: number;
  onThreshold: (v: number) => void;
  weights: SignalWeights;
  onToggle: (key: keyof SignalWeights) => void;
  onRunPipeline: () => void;
  onExport: () => void;
  running: boolean;
  edgeCount: number;
  visibleCount: number;
}

export function LeftPanel({
  threshold,
  onThreshold,
  weights,
  onToggle,
  onRunPipeline,
  onExport,
  running,
  edgeCount,
  visibleCount,
}: LeftPanelProps) {
  const signals = [
    {
      key: 'pgp' as const,
      label: 'PGP Key Match',
      weight: 'w1',
      value: weights.pgp,
      icon: KeyRound,
      color: 'text-violet-400',
    },
    {
      key: 'wallet' as const,
      label: 'Crypto Wallet Match',
      weight: 'w2',
      value: weights.wallet,
      icon: Wallet,
      color: 'text-amber-400',
    },
    {
      key: 'stylometry' as const,
      label: 'Stylometry',
      weight: 'w3',
      value: weights.stylometry,
      icon: PenTool,
      color: 'text-cyan-400',
    },
  ];

  return (
    <aside className="flex w-full flex-col gap-4 overflow-y-auto border-r border-slate-800 bg-[#0f172a]/60 p-4">
      <section>
        <div className="mb-3 flex items-center gap-2">
          <Sliders className="h-4 w-4 text-cyan-400" />
          <h2 className="font-mono text-xs font-semibold uppercase tracking-wider text-slate-300">
            Filter Controls
          </h2>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-900/50 p-3">
          <div className="mb-2 flex items-center justify-between">
            <label className="font-mono text-[11px] text-slate-400">
              Score Threshold <span className="text-slate-600">(S)</span>
            </label>
            <span className="rounded bg-cyan-500/15 px-2 py-0.5 font-mono text-xs font-semibold text-cyan-300">
              {threshold.toFixed(2)}
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={threshold}
            onChange={(e) => onThreshold(parseFloat(e.target.value))}
            className="w-full accent-cyan-500"
          />
          <div className="mt-1 flex justify-between font-mono text-[10px] text-slate-600">
            <span>0.00</span>
            <span>1.00</span>
          </div>
          <p className="mt-2 font-mono text-[10px] leading-relaxed text-slate-500">
            Edges with <span className="text-slate-300">S &lt; {threshold.toFixed(2)}</span> are hidden.
            Showing <span className="text-cyan-300">{visibleCount}</span> / {edgeCount} links.
          </p>
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-mono text-xs font-semibold uppercase tracking-wider text-slate-300">
          Signal Weights
        </h2>
        <div className="space-y-2">
          {signals.map((s) => {
            const active = s.value > 0;
            return (
              <button
                key={s.key}
                onClick={() => onToggle(s.key)}
                className={`flex w-full items-center justify-between rounded-lg border px-3 py-2.5 text-left transition-colors ${
                  active
                    ? 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
                    : 'border-slate-800 bg-slate-900/20 opacity-50 hover:opacity-70'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <s.icon className={`h-4 w-4 ${active ? s.color : 'text-slate-600'}`} />
                  <div>
                    <div className="font-mono text-xs text-slate-200">{s.label}</div>
                    <div className="font-mono text-[10px] text-slate-500">
                      {s.weight} = {s.value.toFixed(2)}
                    </div>
                  </div>
                </div>
                <div
                  className={`h-4 w-4 rounded-full border-2 ${
                    active ? 'border-cyan-400 bg-cyan-400/30' : 'border-slate-700'
                  }`}
                />
              </button>
            );
          })}
        </div>
        <div className="mt-3 rounded-lg border border-slate-800 bg-slate-950/60 p-3">
          <div className="mb-1 flex items-center gap-2">
            <Fingerprint className="h-3.5 w-3.5 text-slate-500" />
            <span className="font-mono text-[10px] uppercase tracking-wider text-slate-500">
              Composite Formula
            </span>
          </div>
          <p className="font-mono text-[11px] leading-relaxed text-slate-300">
            S = (w1 · Key) + (w2 · Wallet) + (w3 · Stylometry)
          </p>
        </div>
      </section>

      <section className="mt-auto space-y-2 pt-2">
        <button
          onClick={onRunPipeline}
          disabled={running}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-cyan-500/90 py-2.5 font-mono text-xs font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-60"
        >
          <Play className="h-4 w-4" />
          {running ? 'Running NLP Pipeline…' : 'Run NLP Pipeline'}
        </button>
        <button
          onClick={onExport}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-900/60 py-2.5 font-mono text-xs font-semibold text-slate-200 transition-colors hover:border-red-500/50 hover:text-red-300"
        >
          <FileText className="h-4 w-4" />
          Export Court Evidence PDF
        </button>
      </section>
    </aside>
  );
}
