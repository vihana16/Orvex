import { useMemo } from 'react';
import {
  User,
  Fingerprint,
  Wallet,
  KeyRound,
  Calendar,
  AlertTriangle,
  FileSearch,
  Hash,
} from 'lucide-react';
import type { GraphNode, GraphEdge, SignalWeights } from '@/types';

interface RightPanelProps {
  node: GraphNode | null;
  edges: GraphEdge[];
  selectedEdge: GraphEdge | null;
  weights: SignalWeights;
  threshold: number;
}

const platformLabel: Record<string, string> = {
  darkweb: 'DarkWeb Forum',
  telegram: 'Telegram',
  pastebin: 'Pastebin',
  crypto: 'Bitcoin',
  pgp: 'PGP Key',
};

const platformIcon: Record<string, typeof User> = {
  darkweb: User,
  telegram: User,
  pastebin: User,
  crypto: Wallet,
  pgp: KeyRound,
};

export function RightPanel({ node, edges, selectedEdge, weights, threshold }: RightPanelProps) {
  const connectedEdges = useMemo(() => {
    if (!node) return [];
    return edges.filter((e) => e.source === node.id || e.target === node.id);
  }, [node, edges]);

  if (!node) {
    return (
      <aside className="flex w-full flex-col items-center justify-center gap-3 border-l border-slate-800 bg-[#0f172a]/60 p-6 text-center">
        <FileSearch className="h-8 w-8 text-slate-600" />
        <p className="font-mono text-xs text-slate-500">
          Select a node or edge to inspect the entity resolution and score breakdown.
        </p>
      </aside>
    );
  }

  const Icon = platformIcon[node.platform] ?? User;

  // compute composite score for this node using the active edge (or highest)
  const displayEdge = selectedEdge && connectedEdges.includes(selectedEdge) ? selectedEdge : connectedEdges[0];
  const score = displayEdge ? displayEdge.score : 0;
  const pgpContrib = displayEdge ? weights.pgp * displayEdge.pgp : 0;
  const walletContrib = displayEdge ? weights.wallet * displayEdge.wallet : 0;
  const styloContrib = displayEdge ? weights.stylometry * displayEdge.stylometry : 0;

  const isHigh = score >= 0.85;

  return (
    <aside className="flex w-full flex-col gap-4 overflow-y-auto border-l border-slate-800 bg-[#0f172a]/60 p-4">
      {/* Profile */}
      <section className="rounded-lg border border-slate-800 bg-slate-900/50 p-4">
        <div className="flex items-start gap-3">
          <div
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg ring-1"
            style={{ backgroundColor: `${node.avatarColor}22`, boxShadow: `0 0 0 1px ${node.avatarColor}55` }}
          >
            <Icon className="h-6 w-6" style={{ color: node.avatarColor }} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="mb-1 flex items-center gap-2">
              <span
                className="rounded px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider"
                style={{ backgroundColor: `${node.avatarColor}22`, color: node.avatarColor }}
              >
                {platformLabel[node.platform]}
              </span>
            </div>
            <h3 className="truncate font-mono text-sm font-semibold text-slate-100">{node.handle}</h3>
            <div className="mt-2 flex flex-col gap-1 font-mono text-[10px] text-slate-500">
              <span className="flex items-center gap-1.5">
                <Calendar className="h-3 w-3" /> First seen: {node.firstSeen}
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="h-3 w-3" /> Last seen: {node.lastSeen}
              </span>
            </div>
          </div>
        </div>
        {node.kind !== 'identity' && (
          <div className="mt-3 flex items-center gap-2 rounded border border-slate-800 bg-slate-950/60 px-2 py-1.5">
            <Hash className="h-3 w-3 text-slate-500" />
            <span className="truncate font-mono text-[10px] text-slate-400">{node.handle}</span>
          </div>
        )}
      </section>

      {/* Score Card */}
      <section className="rounded-lg border border-slate-800 bg-slate-900/50 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Fingerprint className="h-4 w-4 text-cyan-400" />
          <h3 className="font-mono text-xs font-semibold uppercase tracking-wider text-slate-300">
            Explainable Score
          </h3>
        </div>

        <div className="mb-3 rounded border border-slate-800 bg-slate-950/60 p-2.5">
          <p className="font-mono text-[10px] leading-relaxed text-slate-400">
            S = (w1 · Key) + (w2 · Wallet) + (w3 · Stylometry)
          </p>
        </div>

        {/* progress bar */}
        <div className="mb-1 flex items-center justify-between">
          <span className="font-mono text-[10px] text-slate-500">Composite Score</span>
          <span
            className={`font-mono text-sm font-bold ${isHigh ? 'text-red-400' : 'text-orange-400'}`}
          >
            S = {score.toFixed(2)}
          </span>
        </div>
        <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              isHigh ? 'bg-gradient-to-r from-red-600 to-red-400' : 'bg-gradient-to-r from-orange-600 to-orange-400'
            }`}
            style={{ width: `${Math.min(score * 100, 100)}%` }}
          />
        </div>

        {/* breakdown */}
        <div className="mt-4 space-y-2.5">
          <ScoreRow
            label="PGP Match"
            icon={KeyRound}
            iconColor="text-violet-400"
            match={displayEdge?.pgp ?? 0}
            weight={weights.pgp}
            contrib={pgpContrib}
          />
          <ScoreRow
            label="Wallet Match"
            icon={Wallet}
            iconColor="text-amber-400"
            match={displayEdge?.wallet ?? 0}
            weight={weights.wallet}
            contrib={walletContrib}
          />
          <ScoreRow
            label="Stylometry"
            icon={AlertTriangle}
            iconColor="text-cyan-400"
            match={displayEdge?.stylometry ?? 0}
            weight={weights.stylometry}
            contrib={styloContrib}
          />
        </div>

        {isHigh && (
          <div className="mt-3 flex items-center gap-2 rounded border border-red-500/40 bg-red-500/10 px-2.5 py-2">
            <AlertTriangle className="h-3.5 w-3.5 text-red-400" />
            <span className="font-mono text-[10px] text-red-300">
              High-confidence link — score exceeds 0.85 threshold
            </span>
          </div>
        )}
      </section>

      {/* Evidence */}
      <section>
        <h3 className="mb-2 font-mono text-xs font-semibold uppercase tracking-wider text-slate-300">
          Extracted Evidence
        </h3>
        {displayEdge ? (
          <div className="space-y-2">
            {displayEdge.evidence.map((ev) => (
              <div key={ev.id} className="rounded-lg border border-slate-800 bg-slate-900/50 p-3">
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="font-mono text-[10px] text-cyan-400">{ev.source}</span>
                  <span className="font-mono text-[9px] text-slate-500">{ev.timestamp}</span>
                </div>
                <p className="font-mono text-[11px] leading-relaxed text-slate-300">
                  {renderExcerpt(ev.excerpt, ev.highlights)}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="font-mono text-[10px] text-slate-500">No evidence linked to this entity.</p>
        )}
      </section>
    </aside>
  );
}

function ScoreRow({
  label,
  icon: Icon,
  iconColor,
  match,
  weight,
  contrib,
}: {
  label: string;
  icon: typeof User;
  iconColor: string;
  match: number;
  weight: number;
  contrib: number;
}) {
  return (
    <div className="flex items-center gap-2">
      <Icon className={`h-3.5 w-3.5 ${iconColor}`} />
      <span className="flex-1 font-mono text-[11px] text-slate-300">{label}</span>
      <span className="font-mono text-[10px] text-slate-500">
        {match.toFixed(2)} | w={weight.toFixed(2)}
      </span>
      <span className="w-16 text-right font-mono text-[11px] font-semibold text-slate-100">
        +{contrib.toFixed(2)}
      </span>
    </div>
  );
}

function renderExcerpt(text: string, highlights: string[]) {
  if (highlights.length === 0) return text;
  const parts: (string | { mark: string })[] = [];
  let remaining = text;
  while (remaining.length > 0) {
    let earliest = -1;
    let matched = '';
    for (const h of highlights) {
      const idx = remaining.indexOf(h);
      if (idx !== -1 && (earliest === -1 || idx < earliest)) {
        earliest = idx;
        matched = h;
      }
    }
    if (earliest === -1) {
      parts.push(remaining);
      break;
    }
    if (earliest > 0) parts.push(remaining.slice(0, earliest));
    parts.push({ mark: matched });
    remaining = remaining.slice(earliest + matched.length);
  }
  return parts.map((p, i) =>
    typeof p === 'string' ? (
      <span key={i}>{p}</span>
    ) : (
      <mark key={i} className="rounded bg-cyan-400/25 px-0.5 font-mono text-cyan-200">
        {p.mark}
      </mark>
    ),
  );
}
