import { useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';
import type { Core, EventObject } from 'cytoscape';
import type { GraphNode, GraphEdge } from '@/types';

interface ThreatGraphProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  threshold: number;
  selectedNodeId: string | null;
  selectedEdgeId: string | null;
  onSelectNode: (id: string | null) => void;
  onSelectEdge: (id: string | null) => void;
  highlightNodeIds: Set<string>;
}

const platformShape: Record<string, string> = {
  darkweb: 'round-rectangle',
  telegram: 'round-triangle',
  pastebin: 'round-tag',
  crypto: 'round-diamond',
  pgp: 'round-hexagon',
};

const platformColor: Record<string, string> = {
  darkweb: '#ef4444',
  telegram: '#06b6d4',
  pastebin: '#64748b',
  crypto: '#f59e0b',
  pgp: '#a78bfa',
};

export function ThreatGraph({
  nodes,
  edges,
  threshold,
  selectedNodeId,
  selectedEdgeId,
  onSelectNode,
  onSelectEdge,
  highlightNodeIds,
}: ThreatGraphProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);

  // init once
  useEffect(() => {
    if (!containerRef.current || cyRef.current) return;
    const cy = cytoscape({
      container: containerRef.current,
      style: [
        {
          selector: 'node',
          style: {
            'label': 'data(label)',
            'text-valign': 'bottom',
            'text-halign': 'center',
            'text-margin-y': 6,
            'font-family': 'ui-monospace, monospace',
            'font-size': 9,
            'color': '#cbd5e1',
            'background-color': 'data(color)',
            'shape': 'data(shape)' as never,
            'width': 26,
            'height': 26,
            'border-width': 2,
            'border-color': '#1e293b',
          },
        },
        {
          selector: 'node:selected',
          style: {
            'border-width': 3,
            'border-color': '#06b6d4',
            'width': 32,
            'height': 32,
          },
        },
        {
          selector: 'edge',
          style: {
            'width': 2,
            'line-color': '#64748b',
            'target-arrow-color': '#64748b',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            'label': 'data(scoreLabel)',
            'font-family': 'ui-monospace, monospace',
            'font-size': 8,
            'color': '#94a3b8',
            'text-rotation': 'autorotate',
            'text-background-color': '#0f172a',
            'text-background-opacity': 0.85,
            'text-background-padding': '2' as never,
          },
        },
        {
          selector: 'edge.high',
          style: {
            'line-color': '#ef4444',
            'target-arrow-color': '#ef4444',
            'line-style': 'solid',
            'width': 3,
          },
        },
        {
          selector: 'edge.mid',
          style: {
            'line-color': '#f97316',
            'target-arrow-color': '#f97316',
            'line-style': 'dashed',
          },
        },
        {
          selector: 'edge:selected',
          style: {
            'line-color': '#06b6d4',
            'target-arrow-color': '#06b6d4',
            'width': 4,
          },
        },
        {
          selector: '.faded',
          style: { opacity: 0.15 },
        },
      ],
      layout: { name: 'cose', animate: false, padding: 30, idealEdgeLength: 90, nodeRepulsion: 9000 },
    });

    cy.on('tap', 'node', (e: EventObject) => {
      e.preventDefault();
      onSelectNode(e.target.id());
    });
    cy.on('tap', 'edge', (e: EventObject) => {
      e.preventDefault();
      onSelectEdge(e.target.id());
    });
    cy.on('tap', (e: EventObject) => {
      if (e.target === cy) {
        onSelectNode(null);
        onSelectEdge(null);
      }
    });

    cyRef.current = cy;

    return () => {
      cy.destroy();
      cyRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // update elements when data changes
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.elements().remove();
    cy.add(
      nodes.map((n) => ({
        group: 'nodes' as const,
        data: {
          id: n.id,
          label: n.kind === 'identity' ? n.handle : n.label,
          color: platformColor[n.platform] ?? '#64748b',
          shape: platformShape[n.platform] ?? 'ellipse',
        },
      })),
    );
    cy.add(
      edges.map((e) => ({
        group: 'edges' as const,
        data: {
          id: e.id,
          source: e.source,
          target: e.target,
          scoreLabel: `S=${e.score.toFixed(2)}`,
        },
        classes: e.score >= 0.85 ? 'high' : 'mid',
      })),
    );
    cy.layout({ name: 'cose', animate: false, padding: 30, idealEdgeLength: 90, nodeRepulsion: 9000 }).run();
  }, [nodes, edges]);

  // update visibility & styling based on threshold / selection
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;

    cy.edges().forEach((edge) => {
      const data = edges.find((e) => e.id === edge.id());
      if (!data) return;
      const visible = data.score >= threshold;
      edge.style('display', visible ? 'element' : 'none');
    });

    cy.elements().removeClass('faded');
    if (highlightNodeIds.size > 0) {
      const keepIds = new Set<string>();
      highlightNodeIds.forEach((id) => keepIds.add(id));
      const toFade = cy.elements().filter((el: any) => {
        if (el.isNode()) return !keepIds.has(el.id());
        if (el.isEdge()) {
          return !(keepIds.has(el.source().id()) && keepIds.has(el.target().id()));
        }
        return true;
      });
      toFade.addClass('faded');
    }
  }, [threshold, edges, highlightNodeIds]);

  // sync selection
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.$(':selected').unselect();
    if (selectedNodeId) cy.getElementById(selectedNodeId).select();
    if (selectedEdgeId) cy.getElementById(selectedEdgeId).select();
  }, [selectedNodeId, selectedEdgeId]);

  return <div ref={containerRef} className="h-full w-full" />;
}
