import { Clock } from 'lucide-react';
import type { GraphEdge, GraphNode } from '@/types';

interface TimelineProps {
  edges: GraphEdge[];
  nodes: GraphNode[];
  threshold: number;
  onSelectNode: (id: string) => void;
  selectedNodeId: string | null;
}

const nodeColor: Record<string, string> = {
  darkweb: '#ef4444',
  telegram: '#06b6d4',
  pastebin: '#64748b',
  crypto: '#f59e0b',
  pgp: '#a78bfa',
};

export function Timeline({ edges, nodes, threshold, onSelectNode, selectedNodeId }: TimelineProps) {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const visibleEdges = edges.filter((e) => e.score >= threshold);
  const events = visibleEdges
    .flatMap((e) => e.events)
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp));

  return (
    <div className="flex h-full flex-col border-t border-slate-800 bg-[#0f172a]/40">
      <div className="flex items-center gap-2 border-b border-slate-800/60 px-4 py-2">
        <Clock className="h-3.5 w-3.5 text-cyan-400" />
        <h3 className="font-mono text-[11px] font-semibold uppercase tracking-wider text-slate-300">
          Event Timeline · OpSec Leaks
        </h3>
        <span className="ml-auto font-mono text-[10px] text-slate-500">{events.length} events</span>
      </div>
      <div className="relative flex-1 overflow-x-auto overflow-y-hidden">
        <div className="relative flex min-w-full items-center px-4 py-6" style={{ minWidth: Math.max(events.length * 90, 400) }}>
          <div className="absolute left-4 right-4 top-1/2 h-px -translate-y-1/2 bg-slate-700/60" />
          {events.map((ev) => {
            const node = nodeMap.get(ev.nodeId);
            const color = node ? nodeColor[node.platform] : '#64748b';
            const isSel = selectedNodeId === ev.nodeId;
            return (
              <button
                key={ev.id}
                onClick={() => onSelectNode(ev.nodeId)}
                className="group relative z-10 flex w-20 shrink-0 flex-col items-center"
              >
                <span className="mb-2 font-mono text-[9px] text-slate-500">{ev.timestamp}</span>
                <span
                  className={`flex h-3 w-3 items-center justify-center rounded-full ring-2 transition-transform group-hover:scale-125 ${
                    isSel ? 'ring-cyan-400' : 'ring-slate-900'
                  }`}
                  style={{ backgroundColor: color }}
                />
                <span className="mt-2 max-w-[72px] truncate text-center font-mono text-[9px] leading-tight text-slate-400 group-hover:text-slate-200">
                  {ev.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
