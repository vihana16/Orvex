import { Search, Activity, Database, Link2, Gauge, ShieldAlert } from 'lucide-react';
import { METRICS } from '@/data';

interface TopNavProps {
  search: string;
  onSearch: (v: string) => void;
}

export function TopNav({ search, onSearch }: TopNavProps) {
  const metrics = [
    { icon: Database, label: 'Scraped Logs', value: METRICS.scrapedLogs },
    { icon: Activity, label: 'Mapped Identities', value: METRICS.mappedIdentities },
    { icon: Link2, label: 'Active Red Links', value: METRICS.activeRedLinks, accent: 'text-red-400' },
    { icon: Gauge, label: 'Pipeline Latency', value: METRICS.pipelineLatency, accent: 'text-cyan-400' },
  ];

  return (
    <header className="border-b border-slate-800 bg-[#090d16]/95 backdrop-blur">
      <div className="flex items-center justify-between gap-4 px-5 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-500/15 ring-1 ring-red-500/40">
            <ShieldAlert className="h-5 w-5 text-red-400" />
          </div>
          <div>
            <h1 className="font-mono text-sm font-semibold tracking-wide text-slate-100">
              OSINT Threat Graph Engine
            </h1>
            <p className="font-mono text-[11px] text-slate-500">I4C Crime Cell · Restricted</p>
          </div>
        </div>

        <div className="relative w-72 max-w-[40vw]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search handle, PGP fingerprint, or wallet…"
            className="w-full rounded-lg border border-slate-700 bg-slate-900/80 py-2 pl-9 pr-3 font-mono text-xs text-slate-200 placeholder:text-slate-600 focus:border-cyan-500/60 focus:outline-none focus:ring-1 focus:ring-cyan-500/30"
          />
        </div>
      </div>

      <div className="flex items-center gap-6 border-t border-slate-800/80 px-5 py-2">
        {metrics.map((m) => (
          <div key={m.label} className="flex items-center gap-2">
            <m.icon className={`h-3.5 w-3.5 ${m.accent ?? 'text-slate-500'}`} />
            <span className="font-mono text-[11px] text-slate-500">{m.label}:</span>
            <span className={`font-mono text-[11px] font-semibold ${m.accent ?? 'text-slate-200'}`}>
              {m.value}
            </span>
          </div>
        ))}
      </div>
    </header>
  );
}
