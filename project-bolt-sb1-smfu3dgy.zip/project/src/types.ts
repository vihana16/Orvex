export type Platform = 'darkweb' | 'telegram' | 'pastebin' | 'crypto' | 'pgp';

export type EntityKind = 'identity' | 'pgp' | 'wallet';

export interface GraphNode {
  id: string;
  label: string;
  platform: Platform;
  kind: EntityKind;
  handle: string;
  firstSeen: string;
  lastSeen: string;
  avatarColor: string;
  // signal contributions for this node (0 or 1 for matches)
  pgpMatch: number;
  walletMatch: number;
  stylometry: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  score: number;
  // per-signal sub-scores for explainability
  pgp: number;
  wallet: number;
  stylometry: number;
  // evidence snippets
  evidence: EvidenceCard[];
  events: TimelineEvent[];
}

export interface EvidenceCard {
  id: string;
  source: string;
  timestamp: string;
  excerpt: string;
  highlights: string[];
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  label: string;
  nodeId: string;
}

export interface SignalWeights {
  pgp: number;
  wallet: number;
  stylometry: number;
}
